Kontour brand assets

Light artwork is for dark backgrounds; dark artwork is for light backgrounds. PNGs are transparent. SVGs preserve the source geometry. Keep proportions and clear space; do not redraw the wordmark or imply endorsement. Small corporate cuts are for heights below 64px; large cuts are for 64px and above.

Guidance and usage questions: https://kontourai.io/brand/
